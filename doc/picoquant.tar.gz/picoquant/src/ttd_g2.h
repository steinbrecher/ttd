#ifndef _TTP_G2_HEADER_SEEN
#define _TTP_G2_HEADER_SEEN

ttd_ccorr_t *ttd_g2(char* infile1, char* infile2, int *retcode);

#endif // _TTP_G2_HEADER_SEEN
